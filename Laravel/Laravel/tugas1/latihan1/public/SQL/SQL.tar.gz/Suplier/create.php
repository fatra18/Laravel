<h2>NAMA</h2>
<br>
<br>
<br>
<form method="POST" action="create-proses.php">
	<label>name</label>	
	<input type="text" name="name">
	<label>category_id</label>	
	<input type="text" name="Alamat">
	<label>harga</label>	
	<input type="text" name="Nomor">
	<label>suplier_id</label>	
	<input type="text" name="Alamat">
	
	
	<button type="submit">kirim</button>
</form>
