<h2>NAMA</h2>
<br>
<br>
<br>
<form method="POST" action="createproses.php">
	<label>name</label>	
	<input type="text" name="name">
	
	<button type="submit">kirim</button>
</form>
