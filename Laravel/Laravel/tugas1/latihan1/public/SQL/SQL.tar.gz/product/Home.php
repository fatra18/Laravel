  <a href="detail-category.php?ID=<?= $data['ID']?>">Makanan</a> 
			    <a href="detail-category.php?ID=<?= $data['ID']?>">Minuman</a> 
			      <a href="detail-category.php?ID=<?= $data['ID']?>">Sayuran</a>  
